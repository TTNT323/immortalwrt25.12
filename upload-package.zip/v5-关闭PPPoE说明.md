# v5：按"光猫拨号 + 路由器 DHCP/静态"砍掉 PPPoE 全套

## 你的组网方式

```
光猫（负责 PPPoE 拨号）
   │  网线
   ▼
EA0326GMP（WAN 走 DHCP 自动获取 或 静态 IP）
   │  Wi-Fi 2.4G
   ▼
手机（游戏）
```

路由器**不做 PPPoE 拨号**，所以 `ppp` 整套用户态程序 + 内核模块都用不上。

## 一、本轮砍掉的 11 项

| 包 | 作用 | 为什么能砍 |
|---|---|---|
| `ppp` | PPP 守护进程本体 | 不拨号就不用 |
| `ppp-mod-pppoe` | PPPoE 协议插件 | 同上 |
| `kmod-ppp` | PPP 内核模块 | 同上 |
| `kmod-pppoe` | PPPoE 内核模块 | 同上 |
| `kmod-pppox` | PPPoX 内核模块 | 同上 |
| `kmod-mppe` | MPPE 加密（PPTP 用） | 同上 |
| `kmod-slhc` | SLHC 压缩（PPP 用） | 同上 |
| `luci-proto-ppp` | LuCI 的 PPP 配置前端 | 界面不再显示 PPPoE 选项 |
| `shellsync` | ppp 的 chat 脚本依赖 | ppp 去掉后无用 |
| `CONFIG_DEFAULT_ppp` | 默认包列表 | 同上 |
| `CONFIG_DEFAULT_ppp-mod-pppoe` | 默认包列表 | 同上 |

## 二、安全性核实（逐项查过源码）

**1. WAN 默认协议是 dhcp，不是 pppoe**
```sh
# package/base-files/files/lib/functions/uci-defaults.sh
ucidef_set_interface_wan() {
    ucidef_set_interface "wan" device "$1" protocol "${2:-dhcp}"
}
```
`${2:-dhcp}` 表示不指定时默认 `dhcp`。

**2. filogic 的 02_network 没有给任何机型指定 pppoe**
所有机型都用 `ucidef_set_interfaces_lan_wan "lan1 lan2 lan3" eth1`，无 pppoe 字样。

**3. 没有其他包反向依赖 ppp**
查了 `netifd`、`dnsmasq`、`firewall4`、`odhcpd`、`base-files`、`procd` 的 Makefile，均无 `+ppp` 依赖。

**4. `luci-proto-ppp` 只是前端**
它的 contents 只有 `Makefile` 和 `htdocs`（JS 文件），不含 netifd 协议处理器。去掉后 LuCI 网络页面只是不再列出 PPPoE 选项，不会报错。

**5. DHCP/静态协议处理链完好**
- `dhcp.sh` 在 `package/network/config/netifd/files/lib/netifd/proto/dhcp.sh`
- `udhcpc` 由 busybox 提供：`CONFIG_BUSYBOX_CONFIG_UDHCPC=y`（保留）
- `netifd` 保留：`CONFIG_PACKAGE_netifd=y`

## 三、当前总量

| 项目 | 数值 |
|---|---|
| 原始启用项 | 1188 |
| 当前启用项 | 1130 |
| 累计关闭 | 62 项 |
| 实际软件包数 | 239 |

## 四、关闭项汇总（四轮累计 62 项）

| 轮次 | 类别 | 项数 |
|---|---|---|
| v1 | zram/调试工具/LuCI冗余/FAT-NLS/虚拟网卡/DNS组件 | 31 |
| v2 | 驱动调试特性(ATE/AirMonitor/Spectrum/ICAP) + ATA/SCSI/加密引擎 | 15 |
| v4 | IPv6 相关 + UPnP 相关 | 10 |
| v5 | PPPoE 全套 | 11（含 2 个 DEFAULT 项） |

注：部分项跨轮次重叠，去重后净关闭 62 项。

## 五、保留的关键项（低延迟核心）

- `kmod-mediatek_hnat` — 硬件 NAT 卸载，降低转发延迟和 CPU 占用
- `luci-app-turboacc-mtk` — 加速引擎管理界面
- `kmod-tcp-bbr` — BBR 拥塞控制
- `kmod-nft-fullcone` — 全锥形 NAT，游戏联机必需
- `mt_wifi` + `wifi-dats` + `wpad-openssl` — 无线驱动全套
- `mtk-smp` — 中断亲和性
- `cpufreq` — CPU 调频控制
- `netifd` + busybox `udhcpc` — DHCP 上网

## 六、刷机后验证（重点确认能上网）

```sh
# 1. WAN 是否拿到 IP（最关键）
ubus call network.interface.wan status | grep -E 'up|address'

# 2. 默认路由是否存在
ip route | grep default

# 3. DNS 是否通
nslookup baidu.com

# 4. PPP 相关应完全消失
ls /usr/sbin/pppd 2>/dev/null        # 应无输出
lsmod | grep -E 'ppp|mppe'           # 应无输出

# 5. 内存对比
free -m
```

**如果 WAN 起不来**：说明你的光猫是桥接模式、实际由路由器拨号。那就把 `config.original` 里的 PPP 相关项改回 `=y`，或用下面命令临时恢复：

```sh
# 临时装回（需要联网，可能不可行）
# 更稳妥：重新编译时把这 11 项改回 y
```

## 七、静态 IP 上网的情况

如果你的 WAN 用固定 IP（不是 DHCP），配置在 LuCI 里设为 `static` 即可，同样不需要 PPP。本方案完全兼容。

## 八、回退方法

`.config` 里把这 11 项改回 `=y`：
```
CONFIG_PACKAGE_kmod-ppp=y
CONFIG_PACKAGE_kmod-pppoe=y
CONFIG_PACKAGE_kmod-pppox=y
CONFIG_PACKAGE_kmod-mppe=y
CONFIG_PACKAGE_kmod-slhc=y
CONFIG_PACKAGE_ppp=y
CONFIG_PACKAGE_ppp-mod-pppoe=y
CONFIG_PACKAGE_luci-proto-ppp=y
CONFIG_PACKAGE_shellsync=y
CONFIG_DEFAULT_ppp=y
CONFIG_DEFAULT_ppp-mod-pppoe=y
```
