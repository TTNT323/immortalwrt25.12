#!/bin/sh
# EA0326GMP 固件级低延迟调优 (Little Code Sauce v3)
# 说明: 无线参数之外, 固件调度/中断/调频同样影响"反应快"。
# 本脚本开机执行一次, 任一步失败不影响系统启动。

log() { logger -t ea0326-latency "$*"; }

# ---------------------------------------------------------------
# 1) CPU 调频: schedutil 在低负载会降频, 游戏突发流量升频有延迟。
#    固定 performance 让 CPU 常驻最高频, 响应更即时(功耗略增)。
# ---------------------------------------------------------------
for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -w "$gov" ] || continue
    echo performance > "$gov" 2>/dev/null && log "governor -> performance ($gov)"
done

# policy 级: 把 min_freq 拉到 max, 防止降频
for pol in /sys/devices/system/cpu/cpufreq/policy*/; do
    [ -d "$pol" ] || continue
    max=$(cat "$pol/scaling_max_freq" 2>/dev/null)
    [ -n "$max" ] && echo "$max" > "$pol/scaling_min_freq" 2>/dev/null
done

# ---------------------------------------------------------------
# 2) 中断亲和性: Wi-Fi 硬中断绑 CPU1, 以太网留 CPU0。
#    避免 Wi-Fi 收包与 NAT 转发抢同一颗核。
# ---------------------------------------------------------------
bind_irq_by_name() {
    pattern="$1"; cpu_mask="$2"
    awk -v pat="$pattern" '
        {
            irq = $1
            sub(/:$/, "", irq)
            if (irq ~ /^[0-9]+$/ && $0 ~ pat) print irq
        }
    ' /proc/interrupts | while read -r irq; do
        [ -n "$irq" ] || continue
        if echo "$cpu_mask" > "/proc/irq/$irq/smp_affinity" 2>/dev/null; then
            log "irq $irq -> $cpu_mask (match: $pattern)"
        fi
    done
}

# CPU0=0x1, CPU1=0x2
bind_irq_by_name "wmac|wifi|warp" "2"
bind_irq_by_name "mtk_eth|eth0|eth1" "1"

# ---------------------------------------------------------------
# 3) RPS: Wi-Fi 收包交给 CPU1 处理, 减轻 CPU0 转发压力。
# ---------------------------------------------------------------
for ifc in ra0 rai0 rax0; do
    [ -d "/sys/class/net/$ifc/queues/rx-0" ] || continue
    echo 2 > "/sys/class/net/$ifc/queues/rx-0/rps_cpus" 2>/dev/null && \
        log "rps $ifc -> cpu1"
done

# ---------------------------------------------------------------
# 4) 网络软中断预算: 提高单次处理量, 减少调度切换开销。
# ---------------------------------------------------------------
[ -w /proc/sys/net/core/netdev_budget ] && echo 600 > /proc/sys/net/core/netdev_budget
[ -w /proc/sys/net/core/netdev_budget_usecs ] && echo 4000 > /proc/sys/net/core/netdev_budget_usecs

log "done"
