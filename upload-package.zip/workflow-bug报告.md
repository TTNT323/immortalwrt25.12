# build-openwrt.yml 找 Bug 与优化报告

基于**仓库线上版本**（`TTNT323/immortalwrt25.12@main`，278 行，SHA256 `6819597A...`）逐行审查，发现 9 个问题，已全部修复。优化版 314 行。

---

## Bug 1【致命】缺 chmod，固件级优化静默失效

**位置**：步骤 7 `Load custom configuration`

**现象**：线上版本只有 `uci-defaults` 的 chmod，缺 `init.d/ea0326-latency` 和 `sbin/ea0326-latency.sh` 两个。

**后果**：
- `cp -rf` 覆盖文件时不保留可执行权限
- 两个脚本落地后没有 `+x`
- 开机服务起不来，调频/中断绑定/RPS 全不执行
- **编译不报错，刷机后也看不出异常**，属于静默失效

**修复**：
```yaml
chmod +x package/base-files/files/etc/init.d/ea0326-latency 2>/dev/null || true
chmod +x package/base-files/files/sbin/ea0326-latency.sh 2>/dev/null || true
```

---

## Bug 2【高】`[ -e x ] && cmd` 在 bash -e 下会中断步骤

**位置**：步骤 4、步骤 7 共 3 处

```sh
[ -e files ] && mv files openwrt/files
[ -e $CONFIG_FILE ] && mv $CONFIG_FILE openwrt/.config
[ -e $FEEDS_CONF ] && mv $FEEDS_CONF openwrt/feeds.conf.default
```

**原因**：GitHub Actions 的 `run` 默认用 `bash -e`。当 `[ -e x ]` 为假，整个 AND-list 返回非 0，`-e` 触发退出，**后续所有命令被跳过**。

**影响**：如果仓库里没有 `files` 目录，步骤 7 会在第一行直接失败，我加的 zip 解压和 uboot 剔除全部不执行。

**修复**：改为 `if` 包裹
```sh
if [ -e files ]; then mv files openwrt/files; fi
```

同类问题还有我加的 `[ -f /tmp/ea0326-pkg/.config ] && cp ...`，一并改为 `if`。

---

## Bug 3【高】`make defconfig` 可能重新打开精简项

**位置**：步骤 9 `Download package`

**原因**：`make defconfig` 会按依赖关系修正配置。若某个关闭的包被其他包 `select` 强制依赖，会被**重新打开**，我的精简白做。

**修复**：defconfig 后加校验，发现被重开就再次关闭，并打印警告：
```sh
for k in kmod-ppp ppp ppp-mod-pppoe kmod-zram zram-swap odhcp6c luci-app-upnp; do
  if grep -q "^CONFIG_PACKAGE_${k}=y" .config; then
    echo "WARNING: CONFIG_PACKAGE_${k} 被重新启用(依赖强制), 已再次关闭"
    sed -i "s/^CONFIG_PACKAGE_${k}=y/# CONFIG_PACKAGE_${k} is not set/" .config
  fi
done
```
同时校验关键保留项（`kmod-mt_wifi`、`kmod-mediatek_hnat`、`kmod-tcp-bbr` 等）确实在。

---

## Bug 4【中】`cd openwrt/bin/targets/*/*` 多目录时报错

**位置**：步骤 12 `Organize files`

```sh
cd openwrt/bin/targets/*/*
```

**原因**：若 `bin/targets` 下出现多个子目录（比如切过配置、或 MULTI_PROFILE 残留），通配符展开成多个参数，`cd` 报 `too many arguments` 直接失败。

**修复**：用 `find` 精确定位
```sh
FW_DIR=$(find openwrt/bin/targets -mindepth 2 -maxdepth 2 -type d | head -n1)
if [ -z "$FW_DIR" ]; then echo '错误: 未找到固件输出目录'; exit 1; fi
cd "$FW_DIR"
```

---

## Bug 5【中】Release 清理分页不全

**位置**：步骤 16

```sh
curl .../releases | jq -r '.[] | ...'
```

**原因**：GitHub API 默认每页 30 条。release 超过 30 个时只拿到第一页，旧 release 清不掉，仓库会越积越多。

**修复**：加 `?per_page=100`。

---

## Bug 6【中】删 tag 用 `git push` 大概率失败

**位置**：步骤 16

```sh
git push origin --delete "$tag" || echo "删除 tag 失败"
```

**原因**：`actions/checkout@v6` 默认 `fetch-depth: 1` 且是 **detached HEAD**，`git push --delete` 依赖推送凭证，默认 `GITHUB_TOKEN` 的 git 凭证在 checkout 后不保证可用。结果就是每次都走 `|| echo` 兜底，**tag 从来没删成功过**。

**修复**：改用 REST API
```sh
curl -s -X DELETE -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/${{ github.repository }}/git/refs/tags/$tag"
```

---

## Bug 7【中】`make` 重试链掩盖真实错误

**位置**：步骤 10

```sh
make -j$(nproc) || make -j1 || make -j1 V=s
```

**问题**：
- 三次尝试共用同一 build 目录，半成品可能让后续重试报出误导性错误
- 失败原因被 `||` 吞掉，日志里看不出第一次到底错在哪

**修复**：改成显式分支 + 阶段性提示
```sh
if ! make -j$(nproc); then
  echo '=== 全核编译失败，降级单核重试 ==='
  if ! make -j1; then
    echo '=== 单核仍失败，带详细日志重试 ==='
    make -j1 V=s
  fi
fi
```
保留复用已编译对象（不清 build 目录），避免重试从零开始。

---

## Bug 8【低】Artifact 无保留期

**位置**：步骤 13

**问题**：`upload-artifact` 默认保留 90 天，每次编译产物几百 MB，很快吃满仓库存储配额。

**修复**：`retention-days: 7`。

---

## Bug 9【低】`ln -sf` 可能创建嵌套链接

**位置**：步骤 3

```sh
ln -sf /workdir/openwrt "$GITHUB_WORKSPACE/openwrt"
```

**问题**：若 `$GITHUB_WORKSPACE/openwrt` 已存在为**目录**，`ln -sf` 会在其中创建 `openwrt` 子链接，而不是替换。首次运行不存在，风险低。

**状态**：未改（改动收益小于风险，且现有流程正常）。

---

## 已确认正常的部分

| 检查项 | 结果 |
|---|---|
| `actions/checkout@v6` | 存在（sha d23441a4） |
| `actions/upload-artifact@v4` | 存在（sha ea165f8d） |
| `softprops/action-gh-release@v3` | 存在（sha 40c2ca6d） |
| `P3TERX/ssh2actions@v1.0.0` | 存在（sha 71006b93） |
| `DEVICE_NAME` 提取 | 单行匹配正常，得 `nokia_ea0326gmp` |
| `date` 时区 | `TZ=Asia/Shanghai` 生效 |
| uboot artifact 剔除 sed | 正则正确，能删 3 行 |
| YAML 语法 | 解析通过，16 个步骤完整 |

---

## 优化版额外收益

1. **编译日志更可诊断**：defconfig 后打印精简项状态和关键保留项
2. **失败重试有明确分界**：能看出是全核失败还是单核也失败
3. **存储占用受控**：artifact 7 天过期
4. **清理真正生效**：release 和 tag 都能删掉

---

## 部署

**这个 workflow 必须重新上传**（线上版本缺 Bug 1 的 chmod，那是最致命的）。

1. 打开 `.github/workflows/build-openwrt.yml` → Edit → 全选删除
2. 粘贴 [build-openwrt.yml](build-openwrt.yml) 完整内容 → Commit
3. 重新上传 [upload-package.zip](upload-package.zip)（内含同样的 workflow 备份 + 最新优化文件）

## 验证清单

编译日志里应能看到：
```
--- 检测到 upload-package.zip，自动解压 ---
--- 应用优化文件覆盖 OK ---
-rwxr-xr-x ... ea0326-latency          ← 必须有 x
-rwxr-xr-x ... ea0326-latency.sh       ← 必须有 x
--- 2.4G dat 关键项 ---
Channel=1
HT_BW=0
...
--- 校验精简项是否保持关闭 ---
--- 关键保留项确认 ---
  OK kmod-mt_wifi
  OK kmod-mediatek_hnat
  OK kmod-tcp-bbr
--- EA0326GMP ARTIFACT lines after strip ---
(none - OK)
```
